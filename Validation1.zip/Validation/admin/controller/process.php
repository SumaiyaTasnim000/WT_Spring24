<?php
$name=$email=$password=$phonenumber=$address=$permanentaddress=$nationselect="";
$nameError=$emailError=$passwordError=$phonenumberError=$addressError=$permanentaddressError=$nationselectError="";

if(isset($_REQUEST['Submit'])){
    $password=$_REQUEST['Password'];
    $phonenumber=$_REQUEST['$Phone Number'];
 if(strlen($_REQUEST['Name'])<4 ){
        $nameError= " Name should be atleast 4 characeters";
       }
       else{
        $name= $_REQUEST['Name'] ;
        }
 if(!empty($_REQUEST["Email"]))
{
   if(!preg_match("aiub.edu",$_REQUEST["Email"]))
{
    $emailError= "please enter a valid email address";

}
else{
    $email= $_REQUEST['Email'];
}

}
else{
    $emailError= "Email is Required";
}

if(strlen($password)<6 || preg_match('/(A-Z)/',$password))
{
    
    $password= $_REQUEST['Password'] ;
   }
   
   else{
    $passwordError= " Password must be at least 6 characters and an uppercase";
    }
if( preg_match('/(0-9)/',$phonenumber) ){
    $phonenumber= $_REQUEST['Phone Number'] ;
       }
       else{
        $phonenumberError= " Phone Number invalid";
        
        }
if(!empty($_REQUEST["Address"])){
            $name=$_REQUEST['Address'];
          }
          else{
             $nameError= "enter an address";
          }   
if(!empty($_REQUEST["Address"])){
            $name=$_REQUEST['Address'];
          }
          else{
             $nameError= "enter a permanent address";
          }   

if(!empty($_REQUEST["Nationality"])){
            $name=$_REQUEST['Nationality'];
          }
          else{
             $nationselectError= "Select nation";
          }   

if(empty( $_FILES['file']['name']))
{
    echo "No file uploaded";
}

move_uploaded_file($_FILES['file']['tmp_name'],"../upload/".$_REQUEST['Email'].".jpg");


}
?> 