<?php
include '../../layouts/header.php';
include '../controller/process.php';
?>
<html>
<head>
</head>
<body>
<form method="POST" action="" enctype="multipart/form-data">

<fieldset>
  <legend>Sign Up Now!:</legend>



Name: <input type="text" name="Name" >
<?php echo $nameError; ?>
<?php echo $name; ?>
<br>
<br>
Email:  
<input type="text" name="Email" >
<?php echo $emailError; ?>
<?php echo $email; ?>
<br>
<br>
Password: <input type="password" name="Password" >
<?php echo $passwordError; ?>
<br>
<br>
Phone Number: <input type="text" name="Phone Number" >
<?php echo $phonenumberError; ?>
<?php echo $phonenumber; ?>
<br>
<br>
Address: <input type="text" name="Address" >
<?php echo $addressError; ?>
<?php echo $address; ?>
<br>
<br>
Permanent Address: <input type="text" name="Permanent Address" >
<?php echo $permanentaddressError; ?>
<?php echo $permanentaddress; ?>
<br>
<br>
Date Of Birth: <input type="date" name="Date Of Birth" >
<br>
<br>
Nationality:
<select>
    <option value="p1">Bangladeshi</option>
    <option value="p2">Others</option>
  </select>
  <?php echo $nationselectError; ?>
<?php echo $nationselect; ?>
  <br>
  <br>
Chose profile picture:
<input type="file" name="file" >
<br>
<br>
<br>
<input type="submit" name="Submit" value="SUBMIT">
<input type="reset" name="Reset" value="RESET">

</table>
</fieldset>
</form>
</body>
</html>

<?php
include '../../layouts/footer.php';
?>