<html>
<head>
</head>
<body>
<h1> Registration</h1>
<?php
$abc= "registration";
$num1="10";
$num2=11;

echo "<h1>I love jerseys no ".$num1."</h1>";
echo "<br>";
echo $num1+$num2;

?>
</body>

</html>