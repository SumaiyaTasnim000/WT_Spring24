<?php
class Model
{

    function OpenCon(){
      $conn= new mysqli("localhost","root","","Medical assistant");
      return $conn;
    }
    function AddStudent($conn,$table, $name, $email, 
    $password, $PhoneNumber, $nationselect){
        $sql="INSERT INTO $table (name,email, password, phonenumber, nationselect) VALUES 
        ('$name', '$email', '$password', '$PhoneNumber', '$nationselect')";
       $result= $conn->query($sql);
       return $result;
    }

}

?>